<?php
    /**
     * Your Twitter App Info
     */
    
    // Consumer Key
    define('CONSUMER_KEY', '5urU989W8K70PT3LPRirgtaNn');
    define('CONSUMER_SECRET', 'dzAF7SOPwgpYacP6K5omUA3bT669C0B2Ai0Eq0kSIrmmbC3LiH');

    // User Access Token
    define('ACCESS_TOKEN', '352481057-WyTDloZOdLZ9KcHDRJu0oNewBM5g2DhHI6RXsnaS');
    define('ACCESS_SECRET', 'vF4AYYevcXkv1jqFojJxKIssAPrpYUDGw49Vxo9OK6sHG');
	
	// Cache Settings
	define('CACHE_ENABLED', false);
	define('CACHE_LIFETIME', 3600); // in seconds
	define('HASH_SALT', md5(dirname(__FILE__)));